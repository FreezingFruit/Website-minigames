# Among Us

Find the impostotr in this sussy WEBSITE

There are 5 Pages in this website, About Us, Home, Math Game, Snake game and wordsearch.
About us can be accessed through the group img in home, the rest have their dedicated buttons. 
Wordsearch may have some issues due to API Disconnects if you have bad connection. Have fun with our site!